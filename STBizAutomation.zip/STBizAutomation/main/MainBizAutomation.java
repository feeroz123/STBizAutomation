package main;

import javax.swing.JOptionPane;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;
import org.openqa.selenium.NoSuchElementException;

import pages.TaskPage;
import pages.homePage;
import pages.loginPage;

public class MainBizAutomation {
	
	public static WebDriver driver;
	static long startTime;
	static long endTime;
	static double duration;
	static double minutes;

	@BeforeMethod
	public static void setup() {
		
		// Note down the Start Time
		startTime = System.currentTimeMillis();
		
		System.setProperty("webdriver.gecko.driver", "E:\\FEEROZ\\SELENIUM\\geckodriver.exe");
		System.setProperty("webdriver.firefox.profile", "default");
		driver = new FirefoxDriver();
		//driver = new ChromeDriver();
		
		driver.manage().window().maximize();
	}

	@Test
	public static void performTask() throws Exception {
		
		Point oldbuttonLocation = null;
		int noOfClicks = 1;
						
		
		// Take user input
		int input = Integer.parseInt(JOptionPane.showInputDialog(null, 
				"1 - Feeroz" + "\n" + 
				"2 - Nisha" + "\n" + 
				"3 - Nadeem" + "\n" + 
				"4 - Nitish" + "\n" + 
				"5 - Piyush Sahu"+ "\n" +
				"6 - Ashish Sahu",
				"Enter User number", JOptionPane.QUESTION_MESSAGE));
		
				
		constants.setUserName(input);
		constants.setPassword(input);
		
		// Load the URL
		loginPage.loadURL(driver);
			
		// Login
		pages.loginPage.loginUser(driver, constants.username, constants.password);
		Thread.sleep(3000);

		// Close popup on the Home Page
		pages.homePage.closeHomePagePopUpWindow(driver);
		
		// Go to View Assignments page
		pages.homePage.clickViewAdvertisements(driver);
		
		while (! driver.getCurrentUrl().equals(constants.tasksPageUrl)) {
			driver.get(constants.tasksPageUrl);
		}
		
				
		// Close the message box if it appears on Task page
		TaskPage.closeTaskPagePopup(driver);
		
		try{
			WebElement button = driver.findElement(By.xpath(constants.buttonXPath));

			oldbuttonLocation = button.getLocation();
			Point newbuttonLocation = oldbuttonLocation;
			int noOfRefresh;

			do {
				noOfRefresh = 0;

				System.out.println("Old Button Location = " + oldbuttonLocation);
				// Replace the old location with new location
				oldbuttonLocation = newbuttonLocation;
				System.out.println("New Button Location = " + newbuttonLocation);

				// ******** Performing the Click *********
				WaitTypes.clickWhenReady(driver, By.xpath(constants.buttonXPath), 10);
				System.out.println("Click performed: " + noOfClicks);
				noOfClicks++;

				// Random wait
				Thread.sleep(WaitTypes.randomWaitTime(driver));

				button = WaitTypes.getWhenVisible(driver, By.xpath(constants.buttonXPath), 5);

				newbuttonLocation = button.getLocation();

				// Refreshing the page if same old button is available again
				while (oldbuttonLocation.equals(newbuttonLocation) && noOfRefresh < 3) {
					System.out.println("** Same link button found !  Refreshing the page... **");
					driver.get(driver.getCurrentUrl()); // Refresh Page
					noOfRefresh = noOfRefresh + 1;

					// Click on 'Resend'on the Firefox Alert dialog box
					TaskPage.closeBrowserAlert(driver);
					// Close the message box if it appears on Task page
					TaskPage.closeTaskPagePopup(driver);
					Thread.sleep(3000);

					// Reassign the value of available button location
					button = WaitTypes.getWhenVisible(driver, By.xpath(constants.buttonXPath), 5);
					newbuttonLocation = button.getLocation();
				}

			} while ((WaitTypes.getWhenVisible(driver, By.xpath(constants.buttonXPath), 5)).isDisplayed() && noOfRefresh < 3);

	} catch (Exception e) {
		
		System.out.print(e.getMessage());
		System.out.println("Normal Link Not Found");

		// Call the FB link handling function here
		System.out.println("------------------ Entering Refresh and Click FB Link module -----------------");
		
		TaskPage.refreshAndClickFBLink(driver);
		
		System.out.println("All Links are completed");
		
		}
		// Note down End Time
		endTime = System.currentTimeMillis();
		
		 duration = (double)endTime - startTime;
		 minutes = duration / 60000.0;
		
		System.out.println("Task completed. Total clicks performed = " + noOfClicks + " in " + minutes + " minutes");
		
	}

	@AfterMethod
	public static void close() throws InterruptedException {
		
		// Redeem ePoints
		homePage.redeemPoints(driver);
		
		//Logout
		
		
		// driver.close();
	}
}
