package main;

public class constants {
	
	public static final String url = "https://www.socialtrade.biz";
	
	//XPath of latest 'Pending' status label
	public static final String latestPendingStatus = "//span[contains(@id,'pending')]/b";
		
	// XPath of Click button	
	public static final String buttonXPath = latestPendingStatus + "//following::td" + "//span[contains(@onclick,'updateTask')]";
			
	
	// Tasks Page URL
	public static final String tasksPageUrl = "https://www.socialtrade.biz/User/EarnePoints.aspx";
											   
	// Task page Pop up Xpath
	public static final String taskPagePopUpXpath = "//div[@id='w2ui-popup']//div[contains(@class,'w2ui-msg-close')]";
	
	// Login page pop up
	public static String loginPagePopUpXpath = "//div[@id='popup']/img";

	
	
	// Facebook account user credentials
	public static String fbUserId = "feerozfarm1@gmail.com";
	public static String fbPassword = "feeroz@farm1";
	
	// User credentials
	public static String username;
	public static String password;
	
	
	// Feeroz - option 1
	private static final String feerozUser = "61250077";
	private static final String feerozPwd = "feeroz@123";
	
	// Nisha - option 2
	private static final String nishaUser = "61312590";
	private static final String nishaPwd = "nisha@123";

	// Nadeem - option 3
	private static final String nadeemUser = "61250265";
	private static final String nadeemPwd = "Lucky@786";
	
	// Nitish - option 4
	private static final String nitishUser = "61416990";
	private static final String nitishPwd = "nitish@123";
	
	// Piyush - option 5
	private static final String piyushUser = "61296142";
	private static final String piyushPwd = "sudha@2012";

	// Ashish - option 6
	private static final String ashishUser = "61675152";
	private static final String ashishPwd = "ashi@2012";

	
	// Set the username based on option selected
	public static String setUserName(int option) {

		switch (option) {
		case 1:
			username = feerozUser;
			break;
		case 2:
			username = nishaUser;
			break;
		case 3:
			username = nadeemUser;
			break;
		case 4:
			username = nitishUser;
			break;
		case 5:
			username = piyushUser;
			break;
		case 6:
			username = ashishUser;
			break;
		default:
			System.out.println("Invalid User number !");
			break;
		}
		
		System.out.println("Username is set as: " + username);
		return username;
	}

	// Set the password based on option selected
	public static String setPassword(int option) {

		switch (option) {
		case 1:
			password = feerozPwd;
			break;
		case 2:
			password = nishaPwd;
			break;
		case 3:
			password = nadeemPwd;
			break;
		case 4:
			password = nitishPwd;
			break;
		case 5:
			password = piyushPwd;
			break;
		case 6:
			password = ashishPwd;
		default:
			System.out.println("Invalid User number !");
			break;
		}
		return password;
	}

}
