package main;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

public class WaitTypes {
	
	/**
	 * Get element when it is ready
	 * @param driver
	 * @param locator
	 * @param timeout
	 * @return
	 */
	public static WebElement getWhenVisible(WebDriver driver, By locator, int timeout) {
		WebElement element = null;
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		return element;
	}

	/**
	 * Click the element once it is ready
	 * @param driver
	 * @param webElement
	 * @param timeout
	 * @return 
	 */
	public static void clickWhenReady(WebDriver driver, By locater, int timeout) {
		WebElement element = null;
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		element = wait.until(ExpectedConditions.elementToBeClickable(locater));
		element.click();
	}

	/**
	 * Poll for element until the element is present or timeout
	 * @param driver
	 * @param locator
	 * @return
	 */
	public static WebElement fluentWait(WebDriver driver, final By locator) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				return driver.findElement(locator);
			}
		});
		return element;
	}
	
	public static int randomWaitTime (WebDriver driver) {
		// Setting up random wait period
		int randomNumber = ThreadLocalRandom.current().nextInt(2, 4 + 1);
		int waitPeriod = randomNumber * 1000;
		int totalWaitPeriod = 32000 + waitPeriod;
		return totalWaitPeriod;
	}
}
