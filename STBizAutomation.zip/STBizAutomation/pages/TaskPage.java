package pages;

import java.util.Set;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import main.WaitTypes;
import main.constants;

public class TaskPage {
	
	static int noOfFBClicks = 0;

	public static void clickFacebookLink(WebDriver driver) throws Exception {

		int i = 0;

		// Handle Facebook links
		try {

			String parentHandle = driver.getWindowHandle();
			Set<String> handles = driver.getWindowHandles();

			// Click on Like Icon of current link
			WaitTypes.clickWhenReady(driver, By.xpath("//button[@id='u_0_2']"), 5);

			for (String handle : handles) {
				driver.switchTo().window(handle);

				// Enter Facebook account details in Facebook login window
				if (driver.getTitle().contains("Facebook")) {
					driver.findElement(By.xpath("//input[@id='email']")).sendKeys(constants.fbUserId);
					driver.findElement(By.xpath("//input[@id='pass']")).sendKeys(constants.fbPassword);
					driver.findElement(By.xpath("//input[@id='u_0_2']")).click();
					System.out.println("Facebook account logged in");

					driver.switchTo().window(parentHandle);
					// Click on Like Icon of current link
					WaitTypes.clickWhenReady(driver, By.xpath("//button[@id='u_0_2']"), 5);
					Thread.sleep(2000);
					driver.switchTo().frame(1);

					// Click on Confirm link text
					driver.findElement(By.xpath("//a[@id='u_1_0']")).click();

					driver.switchTo().defaultContent();

					// Switching to the Facebook page to LIKE it
					Set<String> handlesMore = driver.getWindowHandles();
					for (String handleNew : handlesMore) {
						driver.switchTo().window(handleNew);
						if (driver.getTitle().contains("Confirm Like")) {
							// Click on Like button on the Facebook window of
							// link
							driver.findElement(By.xpath("//button[text()='Like']")).click();
							driver.switchTo().window(parentHandle);
							break;
						}

					}

					break;
				}

				else {
					Thread.sleep(2000);
					driver.switchTo().frame(1);

					// Click on Confirm link text
					driver.findElement(By.xpath("//a[@id='u_1_0']")).click();

					driver.switchTo().defaultContent();

					// Switching to the Facebook page to LIKE it
					Set<String> handlesMore = driver.getWindowHandles();
					for (String handleNew : handlesMore) {
						driver.switchTo().window(handleNew);
						if (driver.getTitle().contains("Confirm Like")) {
							// Click on Like button on the Facebook window of
							// link
							driver.findElement(By.xpath("//button[text()='Like']")).click();
							driver.switchTo().window(parentHandle);
							break;
						}
					}

				}

			}

		} catch (TimeoutException e) {
			// If the Like button is not found, Click on Refresh link icon
			driver.findElement(By.xpath("//td//span[starts-with(@id,'refresh_')]/i")).click();
			Thread.sleep(2000);
			TaskPage.clickFacebookLink(driver);
		}

	}

	public static WebElement getFBLikeButton(WebDriver driver) {
		
		driver.switchTo().frame(0);
		WebElement FBLikeButton = driver.findElement(By.xpath("//button[@id='u_0_2']"));
		driver.switchTo().defaultContent();
		
		return FBLikeButton;
		
	}
	
	public static void refreshAndClickFBLink(WebDriver driver) {

		try {
					
			do {
				driver.switchTo().defaultContent();		
				WaitTypes.getWhenVisible(driver,By.xpath("//td//span[starts-with(@id,'refresh_')]/i"), 5).click();

				System.out.println("Refreshed FB link");
				Thread.sleep(1000);
				driver.get(driver.getCurrentUrl()); // Refresh Page
				System.out.println("Refreshed the page");

				WaitTypes.clickWhenReady(driver, By.xpath(constants.buttonXPath), 5);
				noOfFBClicks = noOfFBClicks + 1;
				System.out.println("FB link Refreshed - Click performed: " + noOfFBClicks);

				// Random wait
				Thread.sleep(WaitTypes.randomWaitTime(driver));
				
				driver.switchTo().frame(1);

			} while (getFBLikeButton(driver).isDisplayed());

		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("No more links !");
		}
	}
	
	// Close the message box if it appears on Task page
	public static void closeTaskPagePopup(WebDriver driver) {

		try {
			WaitTypes.clickWhenReady(driver, By.xpath(constants.taskPagePopUpXpath), 15);
		} catch (TimeoutException e) {
			System.out.println("Popup was not present");
		}
	}

	// Click on 'Resend'on the Firefox Alert dialog box
	public static void closeBrowserAlert(WebDriver driver) {
		try {
			Alert firefixAlertMessage = driver.switchTo().alert();
			firefixAlertMessage.accept();
		} catch (Exception e) {
			System.out.println("Clicked Resend on Browser Alert");
		}
	}

}
