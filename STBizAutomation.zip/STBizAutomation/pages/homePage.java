package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import main.WaitTypes;



public class homePage {
	
	private static WebElement element;
	
	
	// Close popup
	public static void closeHomePagePopUpWindow(WebDriver driver) throws InterruptedException{
		Thread.sleep(2000);
		try {
		WaitTypes.clickWhenReady(driver, By.xpath("//div[@id='popup']//img[@class='close-image']"), 15);
		System.out.println("Home Page popup closed");
		} catch (Exception e) {
			System.out.println("Home Page popup not found");
		}
	}
	
	
	// Close Notice popup
		public static void closeNoticePopUpWindow(WebDriver driver) throws InterruptedException{
			Thread.sleep(2000);
			try {
			WaitTypes.clickWhenReady(driver, By.xpath("//button[text()='Next...']"), 5);
			System.out.println("Notice popup closed");
			} catch (Exception e) {
				System.out.println("Notice popup not found");
			}
		}

	// Click on View Assignments and open in new tab
		public static void clickViewAdvertisements(WebDriver driver) throws InterruptedException {
			WaitTypes.clickWhenReady(driver, By.xpath("//a[@href='EarnePoints.aspx']"), 10);
			System.out.println("Clicked on 'View Advertisements'");
		}

	// Perform Redeem ePoints action
		public static void redeemPoints(WebDriver driver) throws InterruptedException {
			// Click on Dashboard button
			WaitTypes.clickWhenReady(driver, By.xpath("//a[@href='dashboard.aspx']"), 5);
			
			// Close any popup in Home page
			pages.homePage.closeHomePagePopUpWindow(driver);
			
			//Click on Manage Campaigns button
			WaitTypes.clickWhenReady(driver, By.xpath("//a[@href='CampaignManagement.aspx']"), 5);
			
			//Click on ePoints tab
			WaitTypes.clickWhenReady(driver, By.id("buyepts"), 5);
			
			//Click on Redeem ePoints button
			WaitTypes.clickWhenReady(driver, By.id("btncalredeemepoints"), 5);
			
			// Identify the available ePOints value
			WebElement avlblPoints = WaitTypes.getWhenVisible(driver, By.id("lblcalredeemepoints"), 5);
			
			JavascriptExecutor js = (JavascriptExecutor) driver; 
			String avlblPointsvalue = (String) js.executeScript("return arguments[0].innerHTML", avlblPoints); 	
			System.out.println("Available epoints for Redeem: " + avlblPointsvalue);
			
			// Enter the ePoints value to redeem
			driver.findElement(By.id("rdmepoints")).sendKeys(avlblPointsvalue);
			
			//Click on Submit button
			WaitTypes.clickWhenReady(driver, By.id("btnRedeem"), 5);
			
			System.out.println("ePoints are redeemed = " + avlblPointsvalue);
			
		}
		
		public static void logout(WebDriver driver) throws InterruptedException {
				
			// Click on Dashboard button
			WaitTypes.clickWhenReady(driver, By.xpath("//a[@href='dashboard.aspx']"), 5);
			
			// Close any popup in Home page
			pages.homePage.closeHomePagePopUpWindow(driver);
			
			WaitTypes.clickWhenReady(driver, By.xpath("//a[@class='dropdown-toggle']"), 5);
			WaitTypes.clickWhenReady(driver, By.xpath("//a[contains(@href,'LogOut')]"), 5);
			
			System.out.println("User logged out");
			
		}
		
		
}
