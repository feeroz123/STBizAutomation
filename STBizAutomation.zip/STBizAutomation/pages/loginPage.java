package pages;

import org.openqa.selenium.*;

import main.WaitTypes;
import main.constants;

public class loginPage {
	
	private static WebElement element;

	private static WebElement userIdField(WebDriver driver) {
		element = driver.findElement(By.id("txtEmailID"));
		return element;
	}
	
	private static WebElement passwordField(WebDriver driver) {
		element = driver.findElement(By.id("txtPassword"));
		return element;
	}
	
	private static WebElement loginButton(WebDriver driver) {
		element = driver.findElement(By.id("CndSignIn"));
		return element;
	}
	
	
	/* Performing actions on webelement */
	
	// Load the main page until it loads properly
	public static void loadURL(WebDriver driver) throws InterruptedException {
		String loginPageUrl = null;
		WebElement loginButton = null;
		do {
			driver.get(constants.url);
			
			// Close login page message pop up
			pages.loginPage.closeLoginPageMsgPopUp(driver);
			
			loginButton = driver.findElement(By.id("txtEmailID"));
			loginButton.click();
			loginPageUrl = driver.getCurrentUrl();
			Thread.sleep(2000);
		} while ( ! loginPageUrl.equals("https://www.socialtrade.biz/"));
		
	}
	
	
	// Message popup
	public static void closeLoginPageMsgPopUp(WebDriver driver) throws InterruptedException{
		Thread.sleep(1000);
		try {
			WaitTypes.clickWhenReady(driver, By.xpath(constants.loginPagePopUpXpath), 15);
			System.out.println("Login page message popup closed");
		} catch (Exception e) {
			System.out.println("Login page message popup not found");
		}
	}
	
	// Enter User Id
	private static void enterUserId (WebDriver driver, String userId) throws InterruptedException {
		element = userIdField(driver);
		element.sendKeys(userId);
		System.out.println("Entered User Id");
		Thread.sleep(1000);
	}
	
	// Enter Password
	private static void enterPassword (WebDriver driver, String pwd) throws InterruptedException {
		element = passwordField(driver);
		element.sendKeys(pwd);
		System.out.println("Entered Password");
		Thread.sleep(500);
	}
	
	// CLick on Login Button
	private static void clickLoginButton(WebDriver driver) {
		element = loginButton(driver);
		element.click();
		System.out.println("Clicked on Login Button");
	}
	
	// Perform User login action
	public static void loginUser(WebDriver driver, String uId, String passwd) throws InterruptedException {
		enterUserId(driver, uId);
		enterPassword(driver, passwd);
		clickLoginButton(driver);
		System.out.println("User Details entered");
		
	}

}
